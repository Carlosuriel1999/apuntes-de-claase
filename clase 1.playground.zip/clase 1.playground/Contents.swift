import UIKit
var str = "Hello, playground"
//5,febrero,2019

//para correr el xcode : user: Macbook    pass: iosdevlab

//Optionals  : variables para manipular los nulos (nil)

//ejemplo       ? es para decir que estamos seguros que esa variable tiene o no valor, de esa forma la var es capaz de manejar el valor , optional

var name: String? = nil // (si lo cambiamos nil por Data ing , ya hay valor)

//Optional Binding (crea una variable si y solo si hay valor en name)  desenvolver:binding
if let nombre = name{
    print(nombre)
}else{
    print("no hay valor")
}



// de manera forzada   ! es para los casos de que sabemos que hay un valor
var name2 = name!
