//
//  ViewController.swift
//  MAPA
//
//  Created by Macbook on 5/2/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit
import MapKit   //bien chido que tiene un buen de cosas
import CoreLocation  // para ubicar un punto    //pide permiso de la ubicacion del usuario


class ViewController: UIViewController, CLLocationManagerDelegate {

    
    @IBOutlet weak var mapa: MKMapView!
    
    var manager = CLLocationManager()  //maneja toda la ubicacion del telefono
    
    var latitud : CLLocationDegrees!
    var longitud : CLLocationDegrees!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        manager.delegate = self
        manager.requestWhenInUseAuthorization()  //mensaje de permiso
        manager.desiredAccuracy = kCLLocationAccuracyBest   // la k es una cte
        manager.stopUpdatingLocation()   // red celular, por wifi empieza a correr :v 
    }


    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            self.longitud = location.coordinate.longitude
            self.latitud = location.coordinate.latitude

        }
    }
    
    @IBAction func getCoords(_ sender: UIButton){
        
        print(longitud, latitud)
        
        let localizacion = CLLocationCoordinate2D(latitude: latitud, longitude: longitud)  // nos da el punto
        let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        
        let region = MKCoordinateRegion(center: localizacion, span: span)
        
        mapa.setRegion(region, animated: true)
        mapa.showsUserLocation = true
        mapa.mapType = .hybrid
    }
    
    
    
}

