//
//  ViewController.swift
//  primera app
//
//  Created by Usuario invitado on 2/5/19.
//  Copyright © 2019 mpoo4. All rights reserved.
//

import UIKit
//LOS :  despues de view signinica una clase o protocolo a aplicar, todo elemento dentro de la clase es un metodo
class ViewController: UIViewController {
//el @ es una referencia de una coneccion, weak como se almacena
    @IBOutlet weak var Etiqueta: UILabel!
    
    @IBOutlet weak var caja: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func Boton(_ sender: UIButton) {
        if  let texto = caja.text{
            print(texto)
            Etiqueta.text = texto
        }
    
    }


}

