//
//  alumnoTableViewController.swift
//  User-Firebase
//
//  Created by macbook on 4/23/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit

class AlumnoTableViewController: UITableViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = .cyan
    }
}

