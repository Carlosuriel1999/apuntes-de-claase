//
//  LoggedViewController.swift
//  User-Firebase
//
//  Created by macbook on 4/11/19.
//  Copyright © 2019 iosLab. All rights reserved.
//

import UIKit
import Firebase
class LoggedViewController: UIViewController {

    @IBOutlet weak var usuario: UILabel!
    
    
    @IBAction func logout(_ sender: Any) {
        do{
            try Auth.auth().signOut()
            dismiss(animated: true, completion: nil)
            
        }catch let error{
            print(error.localizedDescription)
        }
    }
    
    

}
