//
//  ViewController.swift
//  mpoo04-firebase
//
//  Created by Macbook on 4/2/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class ViewController: UIViewController {

    
    @IBOutlet weak var email: UITextField!
    
    
    @IBOutlet weak var password: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    
    @IBAction func registerUser(_ sender: UIButton) {
        
        guard let emailUser  = email.text, emailUser != "",       //creame un avariable de que biene de y verifica que no este vacia
            let passUser = password.text, passUser != "" else{    // tambie """""" sino solo sal
                print("datoas no validos")
                return
        }
        
        Auth.auth().createUser(withEmail: emailUser, password: passUser) { (user, error) in
            if let error = error{
            
            print("no se pudo crear")
            print(error.localizedDescription)
            return
            }
            
            print("Usuario creado: " + user!.user.uid)
            
        }
        
    }
    
  

}

