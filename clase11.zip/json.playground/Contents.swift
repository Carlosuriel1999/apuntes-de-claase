import UIKit
import PlaygroundSupport  // para consultas de internet

struct Results: Codable{
    var rersulCount: Int
    var results: [Track]
}
struct Track: Codable{
    var trackname: String
}

let url = URL(string:  "https://itunes.apple.com/search?term=mecano")
let jsonDecoder = JSONDecoder() // toma dato que quieres y lo mete emn donde quieres

let Task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
    
    if let data = data, let resultado = try? jsonDecoder.decode(Results.self, from: data){
        for track in resultado.results{
            print(track.trackname)
        }
    }

}
Task.resume()











PlaygroundPage.current.needsIndefiniteExecution = true   //siempre a foinal de codigo que indica que el servidor va a seguir sacando datos

