//
//  ViewController.swift
//  Tablas
//  Clase 6  26-feb-2019
//  Created by carlos  on 2/26/19.
//  Copyright © 2019 com. All rights reserved.
//
// tableview controller para vistas completas y sin datos activos( como botones que hagan algo)
//protocolos nos da el diseño del metodo
// la tabla necesita 2 protocolos Uitableviewdatasource y  UITableViewDelegate
import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var tabla: UITableView!
    
    var alumnos: [String] = ["carlos", "pedro", "juan", "julio" , "ramon"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    //funciuones de protocolo UITableViewDataSource
    
    //regresa un entero, numberOfRowsInSection es numero de renglones, este metodo pinta lod renglones en la secion
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count  // numero de renglones a regresar
    }
    
    //indexPath tiene info de los renglones, cual fue tocadfo etc.
    // dame una celda para el renglon en => la funcion de abajo
    // dame una celda reusable dequeueReusableCell
    
    //delegar tableview a asu controlador en main dando click a table view y galar a la vista y darle dataSource => da los datos
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.backgroundColor = .magenta
        cell.textLabel!.text = alumnos[indexPath.row]
        
        return cell   // se va allamar 4 veces porq pedi 4 celdas
    }
    
    // se selecciono el renglon en
    
    // delegar => ve la seciones disponibles
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }
    // funcion preparame mandamos el dato de la celda 
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = tabla.indexPathForSelectedRow
        let secondView = segue.destination as? SecondViewController
        secondView?.dato = alumnos[(indexPath?.row)!]
    }
    

}

