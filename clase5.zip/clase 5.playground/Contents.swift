import UIKit

// cuando trabajamos con clase debemo crrear nuestro inicializador
// self es la instancia de la clase (yo) para acceder en las propiedades

//___________Modelo de datos________________
class Dulce{
    var nombre: String
    var precio: Float
    var gramos: Int
    
    init(nombre: String, precio: Float, gramos: Int){
        self.nombre = nombre
        self.precio = precio
        self.gramos = gramos
    }
}

// clases son referencias de valor, no se mueven por lo tanto se usa let, estructuras no se mueven pero sus datos si por eso es var
// usar clase para valores o herencia, caso contrario full estructuras


//super es de clase padre
class Pan : Dulce{
    var delDia: Bool
    override init(nombre: String, precio: Float, gramos: Int) {
        self.delDia = true
        super.init(nombre: nombre, precio: precio, gramos: gramos)
    
    }
    
        init(nombre: String, precio: Float, gramos: Int, delDia: Bool) {  // la que creamos
        self.delDia = delDia
        super.init(nombre: nombre, precio: precio, gramos: gramos)
    }
}




// relacion de uso cuando a una clase llamamos a otra de otra clase
class Caja{
    let dulces : [Dulce]  // inyecion porque metemos u a referencia de otra clase en otra
    
    init(dulces: [Dulce]){
        self.dulces = dulces
    }
    
    func getTotal() -> Float{
        var total : Float = 0.0
        for dulce in dulces{
            total += dulce.precio
        
        
        }
        return total
    }
}
let bubulubu = Dulce(nombre: "Bubulubu", precio: 7.00, gramos: 10)
let paleta = Dulce(nombre: "Paleta", precio: 10.0, gramos: 5)
let dona = Pan(nombre: "dona", precio: 30.0, gramos: 50)

//let concha = Pan(nombre: "concha", precio: 30.0, gramos: 50) agregando una nueva

var arregloDulces = [bubulubu, paleta, dona, ]    //concha//] 
let caja = Caja(dulces: arregloDulces)
caja.getTotal()
