import UIKit
// clase 3 12-feb-2019
// la flecha es devolver algo
func sumar(a: Int, b: Int) -> Int {
    return (a + b)
}

func calcular(a: Int, b: Int) -> (suma: Int, mult: Int){
    return (a + b, a * b)
}


sumar(a: 3, b: 5)

let resultado = calcular(a: 3, b: 5)
resultado.suma
resultado.mult
// parametros en funciones son constantes, inout se usa para eso., & es la direccion

var edad: Int = 21

func cambiaEdad(e: inout Int){
    e += 1
    print(e)
}

cambiaEdad(e: &edad)
print(edad)


//---------------------------------------PROGRMACION FUNCIONAL--------------------------------------------------
func printValue(str: String){
    print(str)
}

let miFuncion = printValue(str :"hola mundo")  //funcion con parametro
let miFuncion2 = printValue  // funcion sin parametro

miFuncion  //las funciones pueden ser asignadas a valores
miFuncion2("adios")

// FUNCIONES COMO PARAMETROS

func add(a : Int, b: Int) -> Int{
    return a + b
}

func substrac(x : Int, y: Int) -> Int{   //firma de la funcion es lo de parantesis pues es k recibe y k regresa
    return x - y
}


func eseculteOperation(  function: (Int, Int) ->Int, p: Int, q: Int){
    let result = function(p, q)
    print(result)
}

let function1 = substrac
function1(3, 7)

eseculteOperation(function: function1, p: 10, q: 20)  // toda funcion que cumpla con la firma entra :v

