//
//  ViewController.swift
//  GPSFb
//
//  Created by Macbook on 5/7/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate {  //location manager es protocolo

    @IBOutlet weak var mapa: MKMapView!
    
    var manager = CLLocationManager()
    var latitud : CLLocationDegrees!
    var longitud : CLLocationDegrees!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        manager.delegate = self
        manager.requestWhenInUseAuthorization()
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.startUpdatingLocation()
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
        latitud = location.coordinate.latitude
        longitud = location.coordinate.longitude
    }
    
    
    @IBAction func start(_ sender: UIButton) {
        
        let localizacion = CLLocationCoordinate2D(latitude: latitud, longitude: longitud)
        let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        let region = MKCoordinateRegion(center: localizacion, latitudinalMeters: span, longitudinalMeters: span)
        
        
    }
    


}

