//
//  ViewController.swift
//  Rutas
//
//  Created by Macbook on 5/7/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate{          //protocolo dentro de la clase para usar funciones en ella//

    
    @IBOutlet weak var mapa: MKMapView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let inicioLocation = CLLocationCoordinate2D(latitude: 19.347397, longitude: -99.170159)
        
        let destinoLocation = CLLocationCoordinate2D(latitude: 19.350333, longitude: -99.169569)

        let inicioPin = Direccion(title: "Direccion1", subtitle: "inicio", coordinate: inicioLocation)
        
        let destinoPin = Direccion(title: "Direccion2", subtitle: "destino", coordinate: destinoLocation)
        
        self.mapa.addAnnotation(inicioPin)
        self.mapa.addAnnotation(destinoPin)
        
        let inicioPlacemark = MKPlacemark(coordinate: inicioLocation)
        let destinoPlacemark = MKPlacemark(coordinate: destinoLocation)
        
        
        // configurar solicitud
        let directionRequest = MKDirections.Request()
        directionRequest.source = MKMapItem(placemark: inicioPlacemark)
        directionRequest.destination = MKMapItem(placemark: destinoPlacemark)
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest) // hace la solicitud
        directions.calculate { (response, error) in
            
            guard let directionResponse = response else {
                if let error = error{
                    print(error.localizedDescription)
                }
                return
            }
            
            let ruta = directionResponse.routes[0]
            self.mapa.addOverlay(ruta.polyline, level: .aboveRoads)
            let rect = ruta.polyline.boundingMapRect
            self.mapa.setRegion(MKCoordinateRegion(rect), animated: true)
            
        }
        
        self.mapa.delegate = self
        
        //distancia
        let inicio = CLLocation(latitude: 19.347397, longitude: -99.170159)
        let destino = CLLocation(latitude: 19.350333, longitude: -99.169569)

        let distancia : CLLocationDistance = inicio.distance(from: destino)
        print(distancia)
        
        let distanciaReal = String(format: "Distancia%02.002f metros", distancia)
        print(distanciaReal)
    }
    
    //funciones del protocolo
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let linea = MKPolylineRenderer(overlay: overlay)
        linea.strokeColor = UIColor.red
        linea.lineWidth = 4.0
        return linea
    }


}

