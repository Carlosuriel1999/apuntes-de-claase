//
//  direcciones.swift
//  Rutas
//
//  Created by Macbook on 5/7/19.
//  Copyright © 2019 Macbook. All rights reserved.
//

import MapKit
import UIKit


class Direccion: NSObject, MKAnnotation {
    
    var coordinate: CLLocationCoordinate2D  //obtiene laptitud y longitud
    var title: String?
    var subtitle: String?
    
    init (title: String, subtitle: String, coordinate: CLLocationCoordinate2D) {
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
    }

}
