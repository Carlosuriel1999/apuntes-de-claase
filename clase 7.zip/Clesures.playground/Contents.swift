import UIKit

var str = "Hello, playground"

// clase 07  dia 4-3-2019
//Cleasure  codigo contenido en una funcion , funcion sin nombre

func suma(x: Int, y: Int){
    print(x + y)
}


func resta(x: Int, y: Int){
    print( x - y)
}

var miFuncion = suma
var miResta = resta
miFuncion(3, 5)
miResta(8, 3)


func ejecutaOperacion(funcion:(Int, Int)->(), a:Int, b:Int){
    funcion(a, b)
}

ejecutaOperacion(funcion: suma, a: 10, b: 20)
///////////

//esto es un closure   defino tipo de dato (miclosure) su firma es no recibir parametro pero regresas cadena, implementacion de funcion anonima (regresa hola)
let miClosure: () -> String = {
    return "hola"
}

var res: String = miClosure()
print(res)
